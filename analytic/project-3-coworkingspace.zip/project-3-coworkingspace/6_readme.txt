# Manoj project- Coworking Space Service Extension
The Coworking Space Service is a set of APIs that enables users to request one-time tokens and administrators to authorize access to a coworking space. This service follows a microservice pattern and the APIs are split into distinct services that can be deployed and managed independently of one another.

For this project, you are a DevOps engineer who will be collaborating with a team that is building an API for business analysts. The API provides business analysts basic analytics data on user activity in the service. The application they provide you functions as expected locally and you are expected to help build a pipeline to deploy it in Kubernetes.


Please find below for the GITHUB link
https://github.com/manojrikk123/Manoj-checkin


## Please find below for the Project Instructions followed as part of this project
1. Set up a Postgres database with a Helm Chart

1.1 I have created the repo and installed the postgres DB by running below commands
helm repo add manoj-repo https://charts.bitnami.com/bitnami
```
1.2 Installed PostgreSQL Helm Chart
```
helm install my-manoj-service manoj-repo/postgresql

2. Create a `Dockerfile` for the Python application. Use a base image that is Python-based.
I have created the docker file for the python application
docker build -t user-api
docker build -t manoj-checkin .
docker push 620831149724.dkr.ecr.us-east-1.amazonaws.com/manoj-checkin:latest

3. Write a simple build pipeline with AWS CodeBuild to build and push a Docker image into AWS ECR
I have container Elactic container registry and logged into amazon ECR by running into below command 
aws ecr get-login-password --region region | docker login --username AWS --password-stdin 620831149724.dkr.ecr.region.amazonaws.com

4. Create a service and deployment using Kubernetes configuration files to deploy the application
I have created the EKS cluster and node group to compute the containers
I have provided the amazonEKScluster policy to the node groups 
I have updated the kubeconfig file
aws eks update-kubeconfig --name manoj_project
I have deployed the user-api and verified the services created under EKS cluster

kubectl apply -f user-api
kubectl describe services user-api
kubectl get pods

5. Check AWS CloudWatch for application logs

I have used below configuration on the kubectl and tagged this role CloudWatchAgentServerPolicy on eks cluster node group to monitor the logs on cloud watch

ClusterName=manoj_project
RegionName=us-east-1
FluentBitHttpPort='2020'
FluentBitReadFromHead='Off'
[[ ${FluentBitReadFromHead} = 'On' ]] && FluentBitReadFromTail='Off'|| FluentBitReadFromTail='On'
[[ -z ${FluentBitHttpPort} ]] && FluentBitHttpServer='Off' || FluentBitHttpServer='On'
curl https://raw.githubusercontent.com/aws-samples/amazon-cloudwatch-container-insights/latest/k8s-deployment-manifest-templates/deployment-mode/daemonset/container-insights-monitoring/quickstart/cwagent-fluent-bit-quickstart.yaml | sed 's/{{cluster_name}}/'${ClusterName}'/;s/{{region_name}}/'${RegionName}'/;s/{{http_server_toggle}}/"'${FluentBitHttpServer}'"/;s/{{http_server_port}}/"'${FluentBitHttpPort}'"/;s/{{read_from_head}}/"'${FluentBitReadFromHead}'"/;s/{{read_from_tail}}/"'${FluentBitReadFromTail}'"/' | kubectl apply -f -

